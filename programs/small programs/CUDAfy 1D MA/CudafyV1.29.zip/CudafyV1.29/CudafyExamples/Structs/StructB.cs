using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Cudafy;

namespace CudafyExamples.Structs
{
    [Cudafy]
    public struct ValueB
    {
        public int value;
    }
}
